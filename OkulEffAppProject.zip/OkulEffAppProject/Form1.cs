using Microsoft.EntityFrameworkCore;
using OkulEffAppProject.Models;

namespace OkulEffAppProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridViewOgrenciler_SelectionChanged(object sender, EventArgs e)
        {
            if (DataGridViewOgrenciler.SelectedRows.Count > 0)
            {
                var selectedRow = DataGridViewOgrenciler.SelectedRows[0];
                txtAd.Text = selectedRow.Cells["Ad"].Value.ToString();
                txtSoyad.Text = selectedRow.Cells["Soyad"].Value.ToString();
                comboBoxSinif.SelectedValue = selectedRow.Cells["SinifId"].Value;
            }
        }

        private void DataGridViewOgrenciler_SelectionChanged_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (var context = new OkulDbContext())
            {
                // ��rencileri DataGridView'e y�kle
                DataGridViewOgrenciler.DataSource = context.Ogrenciler
                    .Include(o => o.Sinif) // S�n�f bilgilerini de y�kle
                    .Select(o => new
                    {
                        o.OgrenciId,
                        o.Ad,
                        o.Soyad,
                        SinifAdi = o.Sinif.SinifAdi,
                        o.SinifId // ComboBox i�in gerekli
                    })
                    .ToList();

                // S�n�flar� ComboBox'a y�kle
                comboBoxSinif.DataSource = context.Siniflar.ToList();
                comboBoxSinif.DisplayMember = "SinifAdi"; // G�r�nen de�er
                comboBoxSinif.ValueMember = "SinifId";   // Arka planda tutulan de�er
            }
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            using (var context = new OkulDbContext())
            {
                // Yeni ��renci olu�tur
                var yeniOgrenci = new Ogrenci
                {
                    Ad = txtAd.Text,
                    Soyad = txtSoyad.Text,
                    SinifId = (int)comboBoxSinif.SelectedValue
                };

                context.Ogrenciler.Add(yeniOgrenci);
                context.SaveChanges(); // Veritaban�na kaydet

                MessageBox.Show("��renci ba�ar�yla eklendi!");
                Form1_Load(sender, e); // Verileri yenile
            }
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            using (var context = new OkulDbContext())
            {
                // Se�ili ��renciyi al
                int selectedId = (int)DataGridViewOgrenciler.SelectedRows[0].Cells["OgrenciId"].Value;
                var ogrenci = context.Ogrenciler.Find(selectedId);

                if (ogrenci != null)
                {
                    ogrenci.Ad = txtAd.Text;
                    ogrenci.Soyad = txtSoyad.Text;
                    ogrenci.SinifId = (int)comboBoxSinif.SelectedValue;

                    context.SaveChanges(); // G�ncellemeleri kaydet
                    MessageBox.Show("��renci ba�ar�yla g�ncellendi!");
                    Form1_Load(sender, e); // Verileri yenile
                }
            }
        }

        private void btnBul_Click(object sender, EventArgs e)
        {
            using (var context = new OkulDbContext())
            {
                // Girilen ID de�erini al
                int ogrenciId;
                if (int.TryParse(txtNumara.Text.Trim(), out ogrenciId)) // ID'yi kontrol et
                {
                    var ogrenci = context.Ogrenciler.Include(o => o.Sinif).FirstOrDefault(o => o.OgrenciId == ogrenciId);

                    if (ogrenci != null)
                    {
                        // ��renciyi TextBox'lara ve ComboBox'a doldur
                        txtAd.Text = ogrenci.Ad;
                        txtSoyad.Text = ogrenci.Soyad;
                        comboBoxSinif.SelectedValue = ogrenci.SinifId;
                    }
                    else
                    {
                        MessageBox.Show("��renci bulunamad�!");
                    }
                }
                else
                {
                    MessageBox.Show("Ge�erli bir numara girin!");
                }
            }
        }

    }


}